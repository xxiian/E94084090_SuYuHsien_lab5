import pygame
import os
MENU_IMAGE = pygame.image.load(os.path.join("images", "upgrade_menu.png"))
UPGRADE_IMAGE = pygame.image.load(os.path.join("images", "upgrade.png"))
SELL_IMAGE = pygame.image.load(os.path.join("images", "sell.png"))

class UpgradeMenu:
    def __init__(self, x, y): #塔的中心位置
        self.menu = pygame.transform.scale(MENU_IMAGE, (200,200))
        self.upgrade=pygame.transform.scale(UPGRADE_IMAGE, (60,35))
        self.sell=pygame.transform.scale(SELL_IMAGE, (40,40))
        self.rect=self.menu.get_rect()
        self.rect.center=(x,y)
        self.__buttons = [Button(self.upgrade,"upgrade",self.rect.centerx,self.rect.centery-75),
                          Button(self.sell,"sell",self.rect.centerx,self.rect.centery+75)]  # (Q2) Add buttons here

    def draw(self, win):
        """
        (Q1) draw menu itself and the buttons
        (This method is call in draw() method in class TowerGroup)
        :return: None
        """
        # draw menu
        win.blit(self.menu,(self.rect.centerx-100,self.rect.centery-100))
        # draw button
        win.blit(self.upgrade,(self.rect.centerx-30,self.rect.centery-90))
        win.blit(self.sell,(self.rect.centerx-20,self.rect.centery+55))


    def get_buttons(self):
        """
        (Q1) Return the button list.
        (This method is call in get_click() method in class TowerGroup)
        :return: list
        """
        return self.__buttons


class Button:
    def __init__(self, image, name, x, y):
        self.name = name
        self.rect=image.get_rect()
        self.rect.center=(x,y)  # center of button

    def clicked(self, x, y):
        """
        (Q2) Return Whether the button is clicked
        (This method is call in get_click() method in class TowerGroup)
        :param x: mouse x
        :param y: mouse y
        :return: bool
        """
        if self.rect.collidepoint(x,y):
            return True
        else:
            return False

    def response(self):
        """
        (Q2) Return the button name.
        (This method is call in get_click() method in class TowerGroup)
        :return: str
        """
        return self.name






